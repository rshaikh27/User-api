const Users = require("../models/user");

const getUsers = async (req, res) => {
  try {
    const users = await Users.find();
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json(err);
  }
};

const createUser = async (req, res) => {
  try {
    const body = req.body;
    const newUser = await Users.create({
      firstName: body.firstName,
      lastName: body.lastName,
      mobileNumber: body.mobileNumber,
      address: body.address,
    });
    res.status(201).json(newUser);
  } catch (err) {
    res.status(500).json(err);
  }
};

const updateUser = async (req, res) => {
  try {
    const body = req.body;
    const userId = req.params.userId;
    console.log(userId);
    const updatedUser = await Users.findByIdAndUpdate(
      userId,
      {
        firstName: body.firstName,
        lastName: body.lastName,
        mobileNumber: body.mobileNumber,
        address: body.address,
      },
      { new: true }
    );
    res.status(200).json(updatedUser);
  } catch (err) {
    res.status(500).json(err);
  }
};

const deleteUser = async (req, res) => {
  try {
    const userId = req.params.userId;
    await Users.findByIdAndDelete(userId);
    res.status(200).json({ message: "User deleted successfully" });
  } catch (err) {
    res.status(500).json(err);
  }
};

module.exports = { getUsers, createUser, updateUser, deleteUser };
